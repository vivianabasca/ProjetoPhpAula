<?php // secreta.php
session_start();
session_name('secreta');
if($_SESSION['validacao']==1){
$avatar = $_SESSION['avatar'];
echo "<img src='$avatar' width='50' height='50' />";
echo " Bem vindo ".$_SESSION['nome']." <br>";
?>
<a href="fotos.php">Fotos</a>
<a href="recado.php">Recados</a>
<?php
}else{
echo " acesso negado ";
}
?>
<br />
<br />
<a href="deslogar.php">Sair</a>